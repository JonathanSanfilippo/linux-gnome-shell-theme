
const Main = imports.ui.main;
const Panel = Main.panel;
const Overview = Main.overview;

class Extension {
    constructor() {
		this.panel_height = Panel.get_height();
    }
    
    _show_panel() {
		Panel.set_height(this.panel_height);
    }
    
    _hide_panel() {
		Panel.set_height(0);
    }

    enable() {
		this._show_panel();
		this.showing = Overview.connect('hiding', this._show_panel.bind(this));
        this.hiding = Overview.connect('showing', this._hide_panel.bind(this));
        let indicator = Main.panel.statusArea['activities'];
        if(indicator != null) {
          indicator.hide();
        }
    }

    disable() {
    	Overview.disconnect(this.showing);
    	Overview.disconnect(this.hiding);
		this._show_panel();
    }
}

function init() {
	return new Extension();
}

